/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Facade;

import Entity.Customer;
import Entity.ItemType;
import Entity.Order;
import Entity.OrderLine;
import static Entity.OrderLine_.Quantity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author Troels
 */
public class FacadeOrder implements FacadeOrderInterface  {
    
      private EntityManagerFactory emf;
    
    public FacadeOrder(EntityManagerFactory emf)
    {
        this.emf = emf;
    }

    @Override
    public Order getOrder(Long id) {
        EntityManager em = emf.createEntityManager();

        try
        {
            em.getTransaction().begin();
            Order order = em.find(Order.class, id);
            em.getTransaction().commit();
            return order;
        }
        finally
        {
            em.close();
        }
        
    }

    @Override
    public Order addOrder(Order o) {
        EntityManager em = emf.createEntityManager();
       
        try
        {
            em.getTransaction().begin();
            em.persist(o);
            em.getTransaction().commit();
            return o;
        }
        finally
        {
            em.close();
        }
    }

    @Override
    public Order linkOrderToCustomer(Order o, Customer c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public OrderLine addOrderLine(OrderLine ol) {
        EntityManager em = emf.createEntityManager();
       
        try
        {
            em.getTransaction().begin();
            em.persist(ol);
            em.getTransaction().commit();
            return ol;
        }
        finally
        {
            em.close();
        }
    }

    @Override
    public ItemType addItemType(ItemType it) {
        EntityManager em = emf.createEntityManager();
       
        try
        {
            em.getTransaction().begin();
            em.persist(it);
            em.getTransaction().commit();
            return it;
        }
        finally
        {
            em.close();
        }
    }

    @Override
    public int totalPrice(Long id) {
          EntityManager em = emf.createEntityManager();
         Order order = em.find(Order.class, id );
          order.getClass(OrderLine.class.)
          
          try {
         
          }
          
          finally
          {
          em.close();
          }
    }
    
}
