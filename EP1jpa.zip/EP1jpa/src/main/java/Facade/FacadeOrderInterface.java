/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Facade;

import Entity.Customer;
import Entity.ItemType;
import Entity.Order;
import Entity.OrderLine;

/**
 *
 * @author Troels
 */
public interface FacadeOrderInterface {
    public Order getOrder(Long id);
    public Order addOrder(Order o);
    public Order linkOrderToCustomer (Order o, Customer c);
    public OrderLine addOrderLine (OrderLine ol);
    public ItemType addItemType (ItemType it);
    public int totalPrice (Long id);
    
    
    
    
    
    
}
