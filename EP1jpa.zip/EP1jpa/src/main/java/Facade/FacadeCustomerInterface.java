/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Facade;

import Entity.Customer;
import java.util.List;

/**
 *
 * @author Troels
 */
public interface FacadeCustomerInterface {
    
    
    
    public Customer getCustomer(Long id);
    public Customer addCustomer (Customer c);
    public Customer deletCustomer(Long id);
    public Customer editCustomer (Customer c);
    public List<Customer> getCustomers();
}
