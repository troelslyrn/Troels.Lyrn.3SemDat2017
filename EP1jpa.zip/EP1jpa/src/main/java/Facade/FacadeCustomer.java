/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Facade;

import Entity.Customer;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Troels
 */
public class FacadeCustomer implements FacadeCustomerInterface{
    
    private EntityManagerFactory emf;
    
      public FacadeCustomer(EntityManagerFactory emf)
    {
        this.emf = emf;
    }
        
        javax.persistence.EntityManager em = emf.createEntityManager();

    @Override
    public Customer getCustomer(Long id) {
       EntityManager em = emf.createEntityManager();

        try
        {
            em.getTransaction().begin();
            Customer customer = em.find(Customer.class, id);
            em.getTransaction().commit();
            return customer;
        }
        finally
        {
            em.close();
        }
         }
         
    

    @Override
    public Customer addCustomer(Customer c)  {
        EntityManager em = emf.createEntityManager();
       
        try
        {
            em.getTransaction().begin();
            em.persist(c);
            em.getTransaction().commit();
            return c;
        }
        finally
        {
            em.close();
        }
    }

    @Override
    public Customer deletCustomer(Long id) {
        EntityManager em = emf.createEntityManager();

        try
        {
            em.getTransaction().begin();
            Customer customer = em.find(Customer.class, id); 
            if( customer != null)
            {
                em.remove(customer);
            }
            em.getTransaction().commit();
            return customer;
        }
        finally
        {
            em.close();
        }
    }

    @Override
    public Customer editCustomer(Customer c){
        EntityManager em = emf.createEntityManager();

        try
        {
            em.getTransaction().begin();
            Customer customer = em.find(Customer.class, c.getId());
            if( customer != null)
            {
                em.merge(c);
            }
            em.getTransaction().commit();
            return customer;
        }
        finally
        {
            em.close();
        }
    }

    @Override
    public List<Customer> getCustomers()   {
        EntityManager em = emf.createEntityManager();

        List<Customer> customers = null;
        
        try
        {
            em.getTransaction().begin();
            customers = em.createQuery("Select c from Customer c").getResultList();
            em.getTransaction().commit();
            return customers;
        }
        finally
        {
            em.close();
        }
    }

  
    
}
