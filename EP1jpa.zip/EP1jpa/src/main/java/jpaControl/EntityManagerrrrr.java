/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jpaControl;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Troels
 */
public class EntityManagerrrrr {
    public static void main(String[] args)
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpaPU");
        
        javax.persistence.EntityManager em = emf.createEntityManager();
                
        em.getTransaction().begin();
        
         em.getTransaction().commit();
        
        em.close();
    }
}
