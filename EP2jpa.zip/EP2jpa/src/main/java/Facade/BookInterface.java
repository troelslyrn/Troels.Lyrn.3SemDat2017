/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Facade;

import Entity.Book;
import Entity.PaperBook;
import Entity.EBook;

/**
 *
 * @author Troels
 */
public interface BookInterface {
    public Book getBook (Long isbn);
    public Book editbook (Book b);
    public Book DeleteBook (Long isbn);
    public Book addBook (Book b);
    public Book getAlleBooks (EBook eb,PaperBook pb);
    
    
}
