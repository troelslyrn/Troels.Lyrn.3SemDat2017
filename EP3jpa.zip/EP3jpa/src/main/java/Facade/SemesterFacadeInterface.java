/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Facade;

import Entity.Semester;
import Entity.Student;
import java.util.List;

/**
 *
 * @author Troels
 */
public interface SemesterFacadeInterface {
   public Semester addSemester(Semester semestr);
   public Semester deleteSemester(Semester semester);
   public Semester getSemester (Long id);
   public int getAlleStudentSemester (List<Student> ArrayList);
   
    
}
